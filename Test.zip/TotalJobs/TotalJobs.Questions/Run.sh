#!/bin/bash
# Pre-requirement:
#   1. Make sure that Api should be build prio to run this program.
#   2. Make sure that Dockerfile and run.sh file should be in TotalJobs.Questions folder.

#run_script()

        # Step 1: Build docker image
        echo
        echo "Building docker image..."        
        docker build . -t auldrinpossa/testimage:1.2

        # Step 1: Run docker image
        echo
        echo "Running docker image..." 
        docker run -p 5000:80 -d auldrinpossa/testimage:1.2

        echo
        echo "Try to open browser... browse url http://localhost:5000/Api/Questions or http://localhost:5000/Api/ExampleQuestions to get the result.."

        open http://localhost:5000/Api/Questions
		open http://localhost:5000/Api/ExampleQuestions




