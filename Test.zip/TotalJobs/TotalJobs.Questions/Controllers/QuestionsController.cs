﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using TotalJobs.Entities;
using TotalJobs.Services;

namespace TotalJobs.Questions.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class QuestionsController : ControllerBase
    {
        private readonly IQuestionService _QuestionService;
        public QuestionsController(IQuestionService QuestionService)
        {
            _QuestionService = QuestionService;
        }

        [HttpGet]
        [Route("api/Questions")]
        public List<Question> Get()
        {
            return _QuestionService.GetQuestions();
        }

        [HttpGet]
        [Route("api/ExampleQuestions")]
        public Example_Questions GetExample()
        {
            return _QuestionService.Example_GetQuestions();
        }
    }
}
