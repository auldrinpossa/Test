﻿using System.Collections.Generic;
using TotalJobs.Entities;
using TotalJobs.Repositories;

namespace TotalJobs.Services
{
    public class QuestionService : IQuestionService
    {
        IQuestionRepository _QuestionRepository;
        public QuestionService(IQuestionRepository QuestionRepository)
        {
            _QuestionRepository = QuestionRepository;
        }

        public Example_Questions Example_GetQuestions()
        {
            return _QuestionRepository.Example_GetQuestions();
        }

        public List<Question> GetQuestions()
        {
            return _QuestionRepository.GetQuestions();
        }
    }
}
