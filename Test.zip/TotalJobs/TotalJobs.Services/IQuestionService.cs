﻿using System.Collections.Generic;
using TotalJobs.Entities;

namespace TotalJobs.Services
{
    public interface IQuestionService
    {
        List<Question> GetQuestions();
        Example_Questions Example_GetQuestions();
    }
}
