﻿namespace TotalJobs.Entities
{
    public class QuestionDetail
    {
        public int QuestionDetailId { get; set; }
        public int QustionId { get; set; }
        public string Question { get; set; }
    }

    public class Example_Questions
    {
        public string[] questionText { get; set; }

        public string questionnaireTitle { get; set; }
    }
}
