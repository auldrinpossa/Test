﻿using System.Collections.Generic;

namespace TotalJobs.Entities
{
    public class Question
    {
        public int QuestionId { get; set; }
        public string QuestionnaireTitle { get; set; }
        public List<QuestionDetail> QuestionText { get; set; }

    }
}
