using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using TotalJobs.Entities;
using TotalJobs.Repositories;
using TotalJobs.Services;

namespace TotalJobs.UnitTest
{
    [TestClass]
    public class QuestionUnitTest
    {
        [TestMethod]
        public void TestMethod_GetQuestions()
        {
            var questionRepository = new Mock<IQuestionRepository>();
            var questionService = new Mock<IQuestionService>();
            var list = QuestionList();


            questionRepository
                .Setup(x => x.GetQuestions())
                .Returns(list);

            var _questionService = new QuestionService(questionRepository.Object);

            Assert.AreEqual(2, _questionService.GetQuestions().Count);

        }

        [TestMethod]
        public void TestMethod_Example_GetQuestions()
        {
            var questionRepository = new Mock<IQuestionRepository>();
            var questionService = new Mock<IQuestionService>();
            var list = ExampleQuestionList();


            questionRepository
                .Setup(x => x.Example_GetQuestions())
                .Returns(list);

            var _questionService = new QuestionService(questionRepository.Object);
            var exquest = _questionService.Example_GetQuestions();
            Assert.AreEqual(list.questionnaireTitle, exquest.questionnaireTitle);

        }

        private List<Question> QuestionList()
        {
            List<Question> QList = new List<Question>();

            List<QuestionDetail> QDetail1 = new List<QuestionDetail>(){
                new QuestionDetail {QuestionDetailId=1,QustionId=1,Question="What is the capital of Cuba?"},
                new QuestionDetail {QuestionDetailId=2,QustionId=1,Question="What is the capital of France?"},
                new QuestionDetail {QuestionDetailId=3,QustionId=1,Question="What is the capital of Poland?"},
                new QuestionDetail {QuestionDetailId=4,QustionId=1,Question="What is the capital of Germany?"}
                };
            Question Q1 = new Question()
            {
                QuestionId = 1,
                QuestionnaireTitle = "Geography Questions",
                QuestionText = QDetail1
            };

            QList.Add(Q1);


            List<QuestionDetail> QDetail2 = new List<QuestionDetail>(){
                new QuestionDetail {QuestionDetailId=5,QustionId=2,Question="Who was Napoleon?"},
                new QuestionDetail {QuestionDetailId=6,QustionId=2,Question="Who was Abraham Lincoln?"},
                new QuestionDetail {QuestionDetailId=7,QustionId=2,Question="Who was Adolf Hitler?"},

                };
            Question Q2 = new Question()
            {
                QuestionId = 2,
                QuestionnaireTitle = "History Questions",
                QuestionText = QDetail2
            };

            QList.Add(Q2);

            return QList;
        }

        private Example_Questions ExampleQuestionList()
        {
            Example_Questions data = new Example_Questions()
            {
                questionnaireTitle = "Geography Question",
                questionText = new string[]
                {
                    "What is the captial of Cuba?",
                    "What is the captial of France?",
                    "What is the captial of Poland?",
                    "What is the captial of Germany?"
                }
            };
            return data;

        }
    }
}
