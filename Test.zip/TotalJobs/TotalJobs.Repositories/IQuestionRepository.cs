﻿using System.Collections.Generic;
using TotalJobs.Entities;

namespace TotalJobs.Repositories
{
    public interface IQuestionRepository
    {
        List<Question> GetQuestions();
        Example_Questions Example_GetQuestions();
    }
}
