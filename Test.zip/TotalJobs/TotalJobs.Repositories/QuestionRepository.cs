﻿using System.Collections.Generic;
using TotalJobs.Entities;

namespace TotalJobs.Repositories
{
    public class QuestionRepository : IQuestionRepository
    {
        public List<Question> GetQuestions()
        {
            return GetQuestionsList();
        }

        public Example_Questions Example_GetQuestions()
        {
            return ExpQuest();
        }

        private List<Question> GetQuestionsList()
        {
            List<Question> QList = new List<Question>();

            List<QuestionDetail> QDetail1 = new List<QuestionDetail>(){
                new QuestionDetail {QuestionDetailId=1,QustionId=1,Question="What is the capital of Cuba?"},
                new QuestionDetail {QuestionDetailId=2,QustionId=1,Question="What is the capital of France?"},
                new QuestionDetail {QuestionDetailId=3,QustionId=1,Question="What is the capital of Poland?"},
                new QuestionDetail {QuestionDetailId=4,QustionId=1,Question="What is the capital of Germany?"}
                };
            Question Q1 = new Question()
            {
                QuestionId = 1,
                QuestionnaireTitle = "Geography Questions",
                QuestionText = QDetail1
            };

            QList.Add(Q1);


            List<QuestionDetail> QDetail2 = new List<QuestionDetail>(){
                new QuestionDetail {QuestionDetailId=5,QustionId=2,Question="Who was Napoleon?"},
                new QuestionDetail {QuestionDetailId=6,QustionId=2,Question="Who was Abraham Lincoln?"},
                new QuestionDetail {QuestionDetailId=7,QustionId=2,Question="Who was Adolf Hitler?"},

                };
            Question Q2 = new Question()
            {
                QuestionId = 2,
                QuestionnaireTitle = "History Questions",
                QuestionText = QDetail2
            };

            QList.Add(Q2);

            return QList;
        }

        private Example_Questions ExpQuest()
        {
            Example_Questions data = new Example_Questions()
            {
                questionnaireTitle = "Geography Question",
                questionText = new string[]
                {
                    "What is the captial of Cuba?",
                    "What is the captial of France?",
                    "What is the captial of Poland?",
                    "What is the captial of Germany?"
                }
            };
            return data;
        }
    }
}
